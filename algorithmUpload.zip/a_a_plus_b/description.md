﻿테스트 문제입니다.

```c
#include <stdio.h>

int main()
{
    printf("%d", "C");

    return 0;
}
```